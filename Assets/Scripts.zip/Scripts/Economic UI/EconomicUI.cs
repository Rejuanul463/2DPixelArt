using TMPro;
using UnityEngine;

public class EconomicUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI totalGoldText;
    [SerializeField] private TextMeshProUGUI requiredGoldText;
    [SerializeField] GuildData guildData;
    private int totalGold;
    private int requiredGold;
    private HeroSelectionForQuestUI _heroSelectionForQuestUI;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        _heroSelectionForQuestUI =  FindObjectOfType<HeroSelectionForQuestUI>();
        GoldCalculation();
    }

    // Update is called once per frame
    void Update()
    {
        GoldCalculation();
    }

    private void GoldCalculation()
    {
        totalGold = guildData.gold;
        requiredGold = _heroSelectionForQuestUI.HeroTotalGold;
        UpdateUI();
    }
    private void UpdateUI()
    {
        totalGoldText.text = totalGold.ToString();
        requiredGoldText.text = requiredGold.ToString();
    }
}
