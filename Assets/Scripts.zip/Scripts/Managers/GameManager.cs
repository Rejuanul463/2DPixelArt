
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance { get; private set; }
    [SerializeField] public UIManager UIManager;
    [SerializeField] public GuildManager GuildManager;
    [SerializeField] public HeroSummoner HeroSummoner;
    [SerializeField] public QuestManager QuestManager;
    [SerializeField] public PopUPManager popUpManager;
    [SerializeField] public Transform SummonPoint;
    [SerializeField] public HeroUI heroUI;
    [SerializeField] public HeroSelectionForQuestUI heroSelectionForQuestUI;
    [SerializeField] public PannelManager pannelManager;
    [SerializeField] public SaveManager saveManager;
    [SerializeField] public UpgradeCounter upgradeCounter;

    [SerializeField] public BuildingData TownHall;
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
        }
        else
        {
            Instance = this;
        }
    }
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        popUpManager = UIManager.popUpPannel.GetComponent<PopUPManager>();
    }

    public void ChangeScene(string sceneName)
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(sceneName);
    }


    public void goToMainMenu()
    {
        saveManager.SaveGame();
        ChangeScene("MainMenu");
    }
}
